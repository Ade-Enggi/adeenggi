<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Ini adalah halaman contact<h2>

</body>
</html>