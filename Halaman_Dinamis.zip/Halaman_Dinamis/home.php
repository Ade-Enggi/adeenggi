<!DOCTYPE html>
<html>
<head>
	<titl></title>
</head>
<body>
	<h2>Ini adalah halaman home</h2>

</body>
</html>