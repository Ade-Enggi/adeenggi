</div>
  <!-- konten -->
  <footer>
    <p>Design © 2021 | ADE ENGGI IMELLIA FEBRIYANTI</p>
  </footer>
  
</body>
</html>
