<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Ini adalah halaman article</h2>

</body>
</html>